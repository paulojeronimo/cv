#!/usr/bin/env bash
set -eou pipefail
cd $(dirname $0)

docker_image=cv-builder

usage() {
  echo Usage: $0 "<build|rmi|'run [something]'>"
  exit 1
}

[ "$#" = 0 ] && usage
while [ "${1:-}" ]; do
  case "$1" in
  build)
    DOCKER_ARGS="build . -t $docker_image"
    echo "Running 'docker $DOCKER_ARGS'"
    docker $DOCKER_ARGS
    ;;
  rmi)
    DOCKER_ARGS="rmi $docker_image"
    echo "Running 'docker $DOCKER_ARGS'"
    docker $DOCKER_ARGS
    ;;
  run*)
    RUN_ARGS="${1#run* }"
    [ "$RUN_ARGS" = run ] && RUN_ARGS=all
    #DOCKER_ENV="-e USER_ID=$USER_ID -e GROUP_ID=$GROUP_ID"
    DOCKER_ENV=
    [ -v dev ] && DOCKER_ENV="$DOCKER_ENV -e ENVIRONMENT=development"
    USER_ARGS=
    if docker info 2>/dev/null | rg -q "rootless"; then
      # Rootless engine maps container root to the host user; --user breaks writes on bind mounts.
      USER_ARGS=
    else
      USER_ID=$(id -u)
      GROUP_ID=$(id -g)
      USER_ARGS="--user $USER_ID:$GROUP_ID"
    fi
    # Mount under the project's own name: source-zip derives the zip's root dir
    # from $(basename "$BASE_DIR"), which would be "workspace" otherwise.
    PROJECT_DIR=/$(basename "$PWD")
    DOCKER_ENV="$DOCKER_ENV -e WORKSPACE_DIR=$PROJECT_DIR -e PUBLISH_DIR=$PROJECT_DIR/publish"
    DOCKER_ARGS="run --rm $USER_ARGS $DOCKER_ENV -w $PROJECT_DIR -v \"$PWD:$PROJECT_DIR\" $docker_image $RUN_ARGS"
    echo "Running 'docker $DOCKER_ARGS'"
    eval docker $DOCKER_ARGS
    ;;
  esac
  shift
  echo
done
